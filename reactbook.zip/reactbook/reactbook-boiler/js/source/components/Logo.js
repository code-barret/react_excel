import React from 'react';

class Logo extends React.Component {
  render() {
    return <div className="Logo"/>;
  }
}

export default Logo