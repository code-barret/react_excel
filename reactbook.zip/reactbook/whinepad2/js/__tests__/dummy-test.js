describe('A suite', () => {
  it('is a spec', () => {
    expect(1).toBe(1);
  });
});
